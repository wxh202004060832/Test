% ======================== 带孔矩形板有限元分析（最终修正版） ========================
clc; clear; close all;

% ======================== 参数设置 ========================
L = 200;        % 板长 (mm)
W = 100;        % 板宽 (mm)
r = 10;         % 孔半径 (mm)
thickness = 2;  % 厚度 (mm)
F = 100;        % 拉力 (N)
E = 210e3;      % 弹性模量 (MPa)
nu = 0.3;       % 泊松比
h0 = 2;         % 网格尺寸控制参数

% ======================== 网格生成 ========================
function [p, t] = createMesh(L, W, r, withHole)
    % 生成基础矩形网格
    [X, Y] = meshgrid(linspace(0, L, 50), linspace(0, W, 25));
    p = [X(:), Y(:)];
    
    if withHole
        % 移除孔洞区域节点
        center = [L/2, W/2];
        dist = sqrt((p(:,1)-center(1)).^2 + (p(:,2)-center(2)).^2);
        p(dist < r, :) = [];
    end
    
    % 三角剖分并优化网格
    DT = delaunayTriangulation(p);
    t = DT.ConnectivityList;
    p = DT.Points;
end

% 生成网格
[p_hole, t_hole] = createMesh(L, W, r, true);    % 带孔板
[p_noHole, t_noHole] = createMesh(L, W, r, false); % 不带孔板

% ======================== 材料属性 ========================
D = E/(1-nu^2) * [1, nu, 0; nu, 1, 0; 0, 0, (1-nu)/2]; % 平面应力弹性矩阵

% ======================== 组装系统矩阵 ========================
function [K, F] = assembleSystem(p, t, D, thickness, F_total, L)
    num_nodes = size(p, 1);
    K = sparse(2*num_nodes, 2*num_nodes);
    F = zeros(2*num_nodes, 1);
    
    % 单元刚度矩阵组装
    for e = 1:size(t,1)
        nodes = t(e,:);
        coords = p(nodes,:);
        [Ke, ~] = elementStiffness(coords, D, thickness);
        
        dofs = reshape([2*nodes-1; 2*nodes], 1, []);
        K(dofs, dofs) = K(dofs, dofs) + Ke;
    end
    
    % 固定左侧边界
    fixed_nodes = find(p(:,1) < 1e-6);
    fixed_dofs = [2*fixed_nodes-1; 2*fixed_nodes];
    K(fixed_dofs,:) = 0; 
    K(:,fixed_dofs) = 0;
    K(fixed_dofs,fixed_dofs) = speye(length(fixed_dofs));
    
    % 施加分布力
    right_nodes = find(p(:,1) > L - 1e-6);
    F_per_node = F_total / length(right_nodes);
    F(2*right_nodes-1) = F_per_node;
end

% 组装系统矩阵
[K_hole, F_hole] = assembleSystem(p_hole, t_hole, D, thickness, F, L);
[K_noHole, F_noHole] = assembleSystem(p_noHole, t_noHole, D, thickness, F, L);

% ======================== 求解位移 ========================
U_hole = K_hole \ F_hole;        % 带孔板位移
U_noHole = K_noHole \ F_noHole;  % 不带孔板位移

% ======================== 结果后处理 ========================
function [node_sigma_x, node_sigma_y, node_tau_xy] = calculateNodeStress(p, t, U, D, L, W, r)
    num_nodes = size(p,1);
    num_elements = size(t,1);
    
    % 初始化节点应力容器
    node_sigma_x = zeros(num_nodes,1);
    node_sigma_y = zeros(num_nodes,1);
    node_tau_xy = zeros(num_nodes,1);
    count = zeros(num_nodes,1);
    
    % 计算单元应力并分配到节点
    for e = 1:num_elements
        nodes = t(e,:);
        coords = p(nodes,:);
        
        % 计算单元应力
        [B, ~] = strainDisplacementMatrix(coords);
        dofs = reshape([2*nodes-1; 2*nodes], [], 1);
        strain = B * U(dofs);
        stress = D * strain;
        
        % 应力分配到节点
        for i = 1:3
            node_sigma_x(nodes(i)) = node_sigma_x(nodes(i)) + stress(1);
            node_sigma_y(nodes(i)) = node_sigma_y(nodes(i)) + stress(2);
            node_tau_xy(nodes(i)) = node_tau_xy(nodes(i)) + stress(3);
            count(nodes(i)) = count(nodes(i)) + 1;
        end
    end
    
    % 计算节点平均应力
    node_sigma_x = node_sigma_x ./ count;
    node_sigma_y = node_sigma_y ./ count;
    node_tau_xy = node_tau_xy ./ count;
    
    % 标记孔洞区域为NaN
    if r > 0
        center = [L/2, W/2];
        dist = sqrt((p(:,1)-center(1)).^2 + (p(:,2)-center(2)).^2);
        node_sigma_x(dist < r) = NaN;
        node_sigma_y(dist < r) = NaN;
        node_tau_xy(dist < r) = NaN;
    end
end

% 计算节点应力
[node_sigma_x_hole, node_sigma_y_hole, node_tau_xy_hole] = calculateNodeStress(p_hole, t_hole, U_hole, D, L, W, r);
[node_sigma_x_noHole, node_sigma_y_noHole, node_tau_xy_noHole] = calculateNodeStress(p_noHole, t_noHole, U_noHole, D, L, W, 0);

% 计算von Mises应力
vm_stress_hole = sqrt(node_sigma_x_hole.^2 + node_sigma_y_hole.^2 - node_sigma_x_hole.*node_sigma_y_hole + 3*node_tau_xy_hole.^2);
vm_stress_noHole = sqrt(node_sigma_x_noHole.^2 + node_sigma_y_noHole.^2 - node_sigma_x_noHole.*node_sigma_y_noHole + 3*node_tau_xy_noHole.^2);

% ======================== 可视化 ========================
function plotNodeField(p, t, node_field, titleText, L, W, r, isHole)
    % 创建新图窗
    figure(gcf);
    
    % 绘制节点场量云图
    trisurf(t, p(:,1), p(:,2), zeros(size(p,1),1), node_field, 'EdgeColor', 'none');
    view(2);
    shading interp;
    colorbar;
    title(titleText);
    axis equal;
    
    % 添加孔洞边界
    if isHole
        hold on;
        theta = linspace(0, 2*pi, 100);
        hole_x = L/2 + r * cos(theta);
        hole_y = W/2 + r * sin(theta);
        plot3(hole_x, hole_y, zeros(size(hole_x)), 'k-', 'LineWidth', 1.5);
        hold off;
    end
end

% 创建对比图窗
figure('Position', [100 100 1200 800])

% 带孔板结果
subplot(3,2,1);
plotNodeField(p_hole, t_hole, U_hole(1:2:end), '带孔板X方向位移 (mm)', L, W, r, true);

subplot(3,2,3);
plotNodeField(p_hole, t_hole, vm_stress_hole, '带孔板von Mises应力 (MPa)', L, W, r, true);

subplot(3,2,5);
plotNodeField(p_hole, t_hole, U_hole(1:2:end)/E, '带孔板X方向应变', L, W, r, true);

% 不带孔板结果
subplot(3,2,2);
plotNodeField(p_noHole, t_noHole, U_noHole(1:2:end), '不带孔板X方向位移 (mm)', L, W, 0, false);

subplot(3,2,4);
plotNodeField(p_noHole, t_noHole, vm_stress_noHole, '不带孔板von Mises应力 (MPa)', L, W, 0, false);

subplot(3,2,6);
plotNodeField(p_noHole, t_noHole, U_noHole(1:2:end)/E, '不带孔板X方向应变', L, W, 0, false);

% ======================== 辅助函数 ========================
function [Ke, Fe] = elementStiffness(coords, D, thickness)
    [B, A] = strainDisplacementMatrix(coords);
    Ke = B' * D * B * A * thickness;
    Fe = zeros(6,1);
end

function [B, A] = strainDisplacementMatrix(coords)
    x = coords(:,1); 
    y = coords(:,2);
    A = polyarea(x, y);
    
    b = [y(2)-y(3); y(3)-y(1); y(1)-y(2)];
    c = [x(3)-x(2); x(1)-x(3); x(2)-x(1)];
    B = [b(1), 0, b(2), 0, b(3), 0;
         0, c(1), 0, c(2), 0, c(3);
         c(1), b(1), c(2), b(2), c(3), b(3)] / (2*A);
end