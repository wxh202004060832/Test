function loadnodes = read_loadnodes
%本函数用于从inp文件中读取被施加集中力的节点的信息
fidin=fopen('model.inp');
i=1;
 while 1
        tline = fgetl(fidin);                           
        if strncmpi(tline,'*Nset, nset=SetFORCE',20)==1   
            while 1
                tline=fgetl(fidin);
                if strncmpi(tline,'** Section: Section-1',21)==1
                    break
                end 
                   loadnodes{i}=tline;              
                   i=i+1;
            end
        end
        if strncmpi(tline,'*END',4)==1
            break
        end
 end
loadnodes=loadnodes';
loadnodes=cell2mat(loadnodes);
loadnodes=str2num(loadnodes);
end

