function [ strain,stress ] = strain_stress( point,weight,transition,displacement,matmtx )
%本函数用来计算应力和应变

% 调用全局变量；
GLOBAL_variable;

for iel=1:nele     %所有单元循环
    % 读取节点坐标值；
    for i=1:nnele
        nd(i)=nodes(iel,i);             
        xcoordinate(i)=coordinate_value(nd(i),1);      
        ycoordinate(i)=coordinate_value(nd(i),2);      
        zcoordinate(i)=coordinate_value(nd(i),3);
    end  			  
    ii=0;
    for intx=1:3   % 积分点循环
        s=point(intx);           
        wtx=weight(intx);        
        for inty=1:3
            t=point(inty);       
            wty=weight(inty);    
            for intz=1:3
                n=point(intz);
                wtz=weight(intz);
                [B,jdet]=BandJ_matrix(xcoordinate,ycoordinate,zcoordinate,s,t,n);  %获取B矩阵
                 for i=1:nnele                                    % 对应位移向量disp位置；
                     disnum(3*i-2)=nd(i)*3-2;
                     disnum(3*i-1)=nd(i)*3-1;
                     disnum(3*i)=nd(i)*3;
                 end
                 for i=1:edof
                     eldisp(i,1)=displacement(disnum(i));         % 单元位移向量；
                 end 
           
                estrain=B*eldisp;               % 高斯积分点应变；  
                estress=matmtx*estrain;             %高斯积分点应力；
                ii=ii+1;
                gstrain(:,ii)=estrain;        %组装27个积分点应变矩阵
                gstress(:,ii)=estress;        %组装27个积分点应力矩阵
            end
        end
    end
    for i=1:6          % 对每个方向（x、y、z、xy、yz，xz）的应力循环，转换到节点
        gzstrain(:,1)=gstrain(i,:);            
        gzstress(:,1)=gstress(i,:);
        zstrain(:,i)=transition\gzstrain;    
        zstress(:,i)=transition\gzstress;    
    end
    strain(iel,:,:)=zstrain;   
    stress(iel,:,:)=zstress;       
end