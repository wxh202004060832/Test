function [B_matrix,Jdet]=BandJ_matrix(xcoordinate,ycoordinate,zcoordinate,s,t,n)
% 该函数用于计算雅可比矩阵以及B矩阵

for i=1:8
    coordinate(i,:)=[xcoordinate(i) ycoordinate(i) zcoordinate(i)];
end

dNsnt=[-(1-n)*(1-t)/8,  -(1-s)*(1-t)/8,  -(1-s)*(1-n)/8;   %计算雅可比矩阵及与其相关的值
    (1-n)*(1-t)/8,   -(1+s)*(1-t)/8,  -(1+s)*(1-n)/8;
    (1+n)*(1-t)/8,   (1+s)*(1-t)/8,  -(1+s)*(1+n)/8;
    -(1+n)*(1-t)/8,   (1-s)*(1-t)/8,  -(1-s)*(1+n)/8;
    -(1-n)*(1+t)/8,  -(1-s)*(1+t)/8,   (1-s)*(1-n)/8;
    (1-n)*(1+t)/8,  -(1+s)*(1+t)/8,   (1+s)*(1-n)/8;
    (1+n)*(1+t)/8,   (1+s)*(1+t)/8,   (1+s)*(1+n)/8;
    -(1+n)*(1+t)/8,  (1-s)*(1+t)/8,    (1-s)*(1+n)/8];
dNsnt=dNsnt';

J=dNsnt*coordinate;  
Jdet=det(J);
dNxyz=J\dNsnt;    


for i=1:8                                         % 计算B矩阵
    Bi=[dNxyz(1,i) 0 0;
        0 dNxyz(2,i) 0;
        0 0 dNxyz(3,i);
        dNxyz(2,i) dNxyz(1,i) 0;
        0 dNxyz(3,i) dNxyz(2,i);
        dNxyz(3,i) 0 dNxyz(1,i)];
    B(:,3*(i-1)+1:3*i)=Bi;
end

B_matrix=B;