function [ node_strain,node_stress ] = ave_strain_stress( strain,stress )
%本函数用于对公用节点的应力、应变进行平均处理

GLOBAL_variable;                                                   %调用全局变量

pub_node = cell(nnode,1);
pub_node_ind = cell(nnode,1);
indpub=zeros(1,nnode);
for i=1:nele
    for j=1:8
        indpub(nodes(i,j))=indpub(nodes(i,j))+1;
        pub_node{nodes(i,j)}(indpub(nodes(i,j)))=i;
        pub_node_ind{nodes(i,j)}(indpub(nodes(i,j)))=j;
    end
end

node_stress=zeros(6,nnode);	                                 % 应力平均
for inode=1:nnode
    numel= indpub(inode);
    for i=1:numel
        ind_nel= pub_node{inode}(i);
        ind_nod=pub_node_ind{inode}(i);
        for j=1:6
            node_stress(j,inode)=node_stress(j,inode)+stress(ind_nel,ind_nod,j);
        end
    end
    node_stress(:,inode)=node_stress(:,inode)/numel;
end

node_strain=zeros(6,nnode);                                  % 应变平均
for inode=1:nnode
    numel= indpub(inode);
    for i=1:numel
        ind_nel= pub_node{inode}(i);
        ind_nod=pub_node_ind{inode}(i);
        for j=1:6
            node_strain(j,inode)=node_strain(j,inode)+strain(ind_nel,ind_nod,j);
        end
    end
    node_strain(:,inode)=node_strain(:,inode)/numel;
end

end