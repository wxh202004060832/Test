% 定义下述变量为全局变量 
global nele;                        %系统的单元总数
global nnode;                     %系统的节点总数
global nnele;                      %每个单元的节点数目
global edof;                       %单个单元的自由度
global ndof;                       %每个节点的自由度
global sdof;                       %系统的自由度
global point;                      %高斯积分点的坐标
global weight;                    %高斯积分点权重
global coordinate_value;    %节点坐标值
global nodes;                     %每个单元对应的节点编号
