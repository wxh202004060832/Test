function  tecplot_disp(IEN,gcoord,displace)
% �����������Mise.plt�У�����Tecplot����ʾ
nel = size(IEN,1);
node= size(gcoord,1);

nodedata=fopen('disp.plt','w');  
fprintf(nodedata,'TITLE="data"\n');
fprintf(nodedata,'VARIABLES=,"X", "Y","Z" ,"Displacement_X","Displacement_Y","Displacement_Z","Displacement_all"\n');
fprintf(nodedata,'ZONE T="%d  "  ,  N=%d, E=%d, ET=BRICK, F=FEPOINT\n',1,node,nel);
Displacement_X=displace(:,1);
Displacement_Y=displace(:,1);
Displacement_Z=displace(:,1);
for i=1:node
    fprintf(nodedata,'%10.10f,%10.10f,%10.10f,%10.10f,%10.10f,%10.10f,%10.10f\n',...
        gcoord(i,1)+0,gcoord(i,2)+0,gcoord(i,3)+0,Displacement_X(3*i-2)+0,Displacement_Y(3*i-1)+0,Displacement_Z(3*i)+0,...
        ((Displacement_X(3*i-2))^2+(Displacement_Y(3*i-1))^2+(Displacement_Z(3*i))^2)^0.5+0);
end  

for i=1:nel
    for j=1:size(IEN,2)
        fprintf(nodedata,'%d       ',IEN(i,j));  
    end
    fprintf(nodedata,'\n');
end
end
