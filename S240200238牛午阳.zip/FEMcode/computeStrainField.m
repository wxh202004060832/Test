function [epsilon_x, epsilon_y] = computeStrainField(nodes, elements, displacements, E, nu)
    % 计算应变场
    % Inputs:
    %   nodes: 节点坐标 (N x 2)
    %   elements: 单元连接关系 (M x 3)
    %   displacements: 节点位移 (2N x 1)
    %   E: 弹性模量
    %   nu: 泊松比
    % Outputs:
    %   epsilon_x: x方向应变 (M x 1)
    %   epsilon_y: y方向应变 (M x 1)

    % 初始化应变数组
    epsilon_x = zeros(size(elements, 1), 1);
    epsilon_y = zeros(size(elements, 1), 1);

    % 遍历每个单元
    for e = 1:size(elements, 1)
        nodes_e = elements(e, :); % 当前单元的节点编号
        x_e = nodes(nodes_e, 1); % 当前单元的x坐标
        y_e = nodes(nodes_e, 2); % 当前单元的y坐标

        % 计算单元面积
        A_e = 0.5 * abs(det([1, 1, 1; x_e(:)'; y_e(:)']));

        % 计算 b_i 和 c_i
        b = [y_e(2) - y_e(3), y_e(3) - y_e(1), y_e(1) - y_e(2)];
        c = [x_e(3) - x_e(2), x_e(1) - x_e(3), x_e(2) - x_e(1)];

        % 计算 B 矩阵
        B = 1 / (2 * A_e) * [b(1), 0, b(2), 0, b(3), 0;
                              0, c(1), 0, c(2), 0, c(3);
                              c(1), b(1), c(2), b(2), c(3), b(3)];

        % 提取当前单元的位移
        u_e = displacements(2*nodes_e - 1); % x方向位移
        v_e = displacements(2*nodes_e);     % y方向位移

        % 计算应变场
        epsilon_x(e) = B(1, :) * [u_e; v_e];
        epsilon_y(e) = B(2, :) * [u_e; v_e];
    end
end