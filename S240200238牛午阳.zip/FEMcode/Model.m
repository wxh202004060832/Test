% 定义几何参数
L = 2.0;       % 结构长度 (m)
H = 2.0;        % 结构高度 (m)
hole_side = 1.4; % 中间正方形孔的边长 (m)


% 创建主矩形
mainRect = [0, L, L, 0; 0, 0, H, H];

% 创建中间的正方形孔
centerHole = [L/2 - hole_side/2, L/2 + hole_side/2, L/2 + hole_side/2, L/2 - hole_side/2;
              H/2 - hole_side/2, H/2 - hole_side/2, H/2 + hole_side/2, H/2 + hole_side/2];


% 使用patch函数绘制几何形状
figure;
patch('Faces', [1, 2, 3, 4], 'Vertices', mainRect', 'FaceColor', 'blue', 'EdgeColor', 'black'); hold on;
patch('Faces', [1, 2, 3, 4], 'Vertices', centerHole', 'FaceColor', 'white', 'EdgeColor', 'black');
axis equal;
xlim([0, L]);
ylim([0, H]);
xlabel('Length (m)');
ylabel('Height (m)');
title('2D Geometry with Holes')
