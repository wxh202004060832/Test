%学号：S240200238
%姓名：牛午阳
%有限元大作业
clc;
clear;

%% 1. 建模
Model;

%% 2. 划分网格
Mesh;

%% 3. 组装刚度矩阵
Matrix;

%% 4. 添加边界条件、载荷与求解
Loads;

%% 5. 节点位移前后位置对比
Comparison;

%% 6. 计算应变场
[epsilon_x, epsilon_y] = computeStrainField(nodes, elements, displacements, E, nu);
% 输出应变场
disp('应变场计算完成，结果存储在 epsilon_x 和 epsilon_y 中');

%% 7. 计算应力场
sigma_x = E / (1 - nu^2) * (epsilon_x + nu * epsilon_y);
sigma_y = E / (1 - nu^2) * (nu * epsilon_x + epsilon_y);

%% 8. 计算最值
% 位移场最值
displacements_tmp = reshape(displacements, 2, size(nodes, 1));
displacements_tmp_x = displacements_tmp(1, :); % x方向位移
displacements_tmp_y = displacements_tmp(2, :); % y方向位移

% 位移幅值
displacement_magnitude = sqrt(displacements_tmp_x.^2 + displacements_tmp_y.^2);

% 最大位移值及位置
[max_displacement, max_disp_idx] = max(displacement_magnitude);
max_disp_node = max_disp_idx; % 最大位移对应的节点
max_disp_node_coords = nodes(max_disp_node, :); % 最大位移节点的坐标

% 应变场最值
[max_epsilon_x, max_epsilon_x_idx] = max(epsilon_x);
[max_epsilon_y, max_epsilon_y_idx] = max(epsilon_y);
epsilon_x_node = elements(max_epsilon_x_idx, :); % 最大应变单元的节点
epsilon_y_node = elements(max_epsilon_y_idx, :);

% 应力场最值
[max_sigma_x, max_sigma_x_idx] = max(sigma_x);
[max_sigma_y, max_sigma_y_idx] = max(sigma_y);
sigma_x_node = elements(max_sigma_x_idx, :); % 最大应力单元的节点
sigma_y_node = elements(max_sigma_y_idx, :);

%% 9. 输出最值信息
disp('====================================');
disp('位移场最值信息:');
disp(['最大位移值：', num2str(max_displacement)]);
disp(['最大位移节点编号：', num2str(max_disp_node)]);
disp(['最大位移节点坐标：', num2str(max_disp_node_coords)]);
disp('====================================');

disp('====================================');
disp('应变场最值信息:');
disp(['X方向最大应变值：', num2str(max_epsilon_x)]);
disp(['X方向最大应变单元节点编号：', num2str(epsilon_x_node)]);
disp(['Y方向最大应变值：', num2str(max_epsilon_y)]);
disp(['Y方向最大应变单元节点编号：', num2str(epsilon_y_node)]);
disp('====================================');

disp('====================================');
disp('应力场最值信息:');
disp(['X方向最大应力值：', num2str(max_sigma_x)]);
disp(['X方向最大应力单元节点编号：', num2str(sigma_x_node)]);
disp(['Y方向最大应力值：', num2str(max_sigma_y)]);
disp(['Y方向最大应力单元节点编号：', num2str(sigma_y_node)]);
disp('====================================');

%% 10. 可视化解应变场
figure;
subplot(1, 2, 1);
pdeplot(mesh, 'XYData', epsilon_x, 'ColorMap', 'jet', 'XYStyle', 'interp');
title('X方向应变场');
xlabel('X轴位置');
ylabel('Y轴位置');
colorbar;

subplot(1, 2, 2);
pdeplot(mesh, 'XYData', epsilon_y, 'ColorMap', 'jet', 'XYStyle', 'interp');
title('Y方向应变场');
xlabel('X轴位置');
ylabel('Y轴位置');
colorbar;

%% 11. 可视化应力场
figure;
subplot(1, 2, 1);
pdeplot(mesh, 'XYData', sigma_x, 'ColorMap', 'jet', 'XYStyle', 'interp');
title('X方向应力场');
xlabel('X轴位置');
ylabel('Y轴位置');
colorbar;

subplot(1, 2, 2);
pdeplot(mesh, 'XYData', sigma_y, 'ColorMap', 'jet', 'XYStyle', 'interp');
title('Y方向应力场');
xlabel('X轴位置');
ylabel('Y轴位置');
colorbar;

%% 12. 可视化位移场
figure;
pdeplot(mesh, 'XYData', displacement_magnitude, 'ColorMap', 'jet', 'XYStyle', 'interp');
title('位移场');
xlabel('X轴位置');
ylabel('Y轴位置');
colorbar;