clear 
clc

E = 6.9e10;        
miu = 0.33;          
L = 4e-3;          
W = 2e-3;          
t = 1e-5;       
nx = 50;           
ny = 25;           


D = E/(1 - miu^2) * [1, miu, 0; miu, 1, 0; 0, 0, (1 - miu)/2];

x = linspace(0, L, nx+1);
y = linspace(0, W, ny+1);
[X, Y] = meshgrid(x, y);
nodes = [X(:), Y(:)];
num_nodes = size(nodes, 1);

elements = zeros(nx*ny, 4);
for i = 1:nx
    for j = 1:ny
        elem_id = (i-1)*ny + j;
        node1 = (i-1)*(ny+1) + j;
        node2 = i*(ny+1) + j;
        node3 = i*(ny+1) + j + 1;
        node4 = (i-1)*(ny+1) + j + 1;
        elements(elem_id, :) = [node1, node2, node3, node4];
    end
end

K = sparse(2*num_nodes, 2*num_nodes);
F = zeros(2*num_nodes, 1);
gauss_points = [-1/sqrt(3), 1/sqrt(3)];
weights = [1, 1];

for elem_id = 1:size(elements, 1)
    elem_nodes = elements(elem_id, :);
    x_elem = nodes(elem_nodes, 1);
    y_elem = nodes(elem_nodes, 2);
    Ke = zeros(8, 8);
    
    for r = gauss_points
        for s = gauss_points
            dN_dr = 0.25 * [s-1, 1-s, 1+s, -1-s];
            dN_ds = 0.25 * [r-1, -r-1, r+1, 1-r];            
            dx_dr = sum(dN_dr .* x_elem');
            dy_dr = sum(dN_dr .* y_elem');
            dx_ds = sum(dN_ds .* x_elem');
            dy_ds = sum(dN_ds .* y_elem');
            J = [dx_dr, dy_dr; dx_ds, dy_ds];
            detJ = det(J);
            invJ = inv(J);                      
            dN_dx = dN_dr * invJ(1,1) + dN_ds * invJ(1,2);
            dN_dy = dN_dr * invJ(2,1) + dN_ds * invJ(2,2);            
            B = zeros(3, 8);
            for i = 1:4
                B(1, 2*i-1) = dN_dx(i);
                B(2, 2*i)   = dN_dy(i);
                B(3, 2*i-1) = dN_dy(i);
                B(3, 2*i)   = dN_dx(i);
            end           
            Ke = Ke + B' * D * B * detJ * t * (weights(1)*weights(2));
        end
    end
    
    for i = 1:4
        for j = 1:4
            K_i = elem_nodes(i);
            K_j = elem_nodes(j);
            K(2*K_i-1:2*K_i, 2*K_j-1:2*K_j) = ...
                K(2*K_i-1:2*K_i, 2*K_j-1:2*K_j) + Ke(2*i-1:2*i, 2*j-1:2*j);
        end
    end
end

force_total = 1;
right_nodes = (nx)*(ny+1)+1 : (nx+1)*(ny+1); 
force_per_node = -1 / length(right_nodes);   
F(2*right_nodes) = force_per_node;         

for j = 1:ny
    elem_id = (nx-1)*ny + j;
    elem = elements(elem_id, :);
    node2 = elem(2);
    node3 = elem(3);
    F(2*node2) = F(2*node2) + force_per_node;
    F(2*node3) = F(2*node3) + force_per_node;
end

left_nodes = 1:ny+1;
fixed_dofs = [2*left_nodes-1, 2*left_nodes];
K(fixed_dofs, :) = 0;
K(fixed_dofs, fixed_dofs) = eye(length(fixed_dofs));
F(fixed_dofs) = 0;

U = K \ F;

node_strain = zeros(num_nodes, 3);
node_stress = zeros(num_nodes, 3);
node_count = zeros(num_nodes, 1);

for elem_id = 1:size(elements, 1)
    elem_nodes = elements(elem_id, :);
    U_e = zeros(8, 1);
    for i = 1:4
        node = elem_nodes(i);
        U_e(2*i-1:2*i) = U(2*node-1:2*node);
    end
    
    r = 0; s = 0;
    dN_dr = 0.25 * [s-1, 1-s, 1+s, -1-s];
    dN_ds = 0.25 * [r-1, -r-1, r+1, 1-r];
    dx_dr = sum(dN_dr .* nodes(elem_nodes, 1)');
    dy_dr = sum(dN_dr .* nodes(elem_nodes, 2)');
    dx_ds = sum(dN_ds .* nodes(elem_nodes, 1)');
    dy_ds = sum(dN_ds .* nodes(elem_nodes, 2)');
    J = [dx_dr, dy_dr; dx_ds, dy_ds];
    invJ = inv(J);
    
    dN_dx = dN_dr * invJ(1,1) + dN_ds * invJ(1,2);
    dN_dy = dN_dr * invJ(2,1) + dN_ds * invJ(2,2);
    
    B = zeros(3, 8);
    for i = 1:4
        B(1, 2*i-1) = dN_dx(i);
        B(2, 2*i)   = dN_dy(i);
        B(3, 2*i-1) = dN_dy(i);
        B(3, 2*i)   = dN_dx(i);
    end
    
    epsilon = B * U_e;
    sigma = D * epsilon;
    
    for i = 1:4
        node = elem_nodes(i);
        node_strain(node, :) = node_strain(node, :) + [epsilon(1), epsilon(2), epsilon(3)];
        node_stress(node, :) = node_stress(node, :) + [sigma(1), sigma(2), sigma(3)];
        node_count(node) = node_count(node) + 1;
    end
end

node_strain = node_strain ./ node_count;
node_stress = node_stress ./ node_count;

sigma_vm = sqrt(node_stress(:,1).^2 + node_stress(:,2).^2 - node_stress(:,1).*node_stress(:,2) + 3*node_stress(:,3).^2);
epsilon_vm = sqrt(node_strain(:,1).^2 + node_strain(:,2).^2 - node_strain(:,1).*node_strain(:,2) + 3*(node_strain(:,3)/2).^2);

disp_magnitude = sqrt(U(1:2:end).^2 + U(2:2:end).^2);
X_grid = reshape(nodes(:,1), ny+1, nx+1);
Y_grid = reshape(nodes(:,2), ny+1, nx+1);
disp_grid = reshape(disp_magnitude, ny+1, nx+1);         
sigma_vm_grid = reshape(sigma_vm, ny+1, nx+1);           
epsilon_vm_grid = reshape(epsilon_vm, ny+1, nx+1);        

figure;
surf(X_grid, Y_grid, disp_grid, 'EdgeColor', 'none');     
view(2); colorbar; title('总位移云图 (m)');

figure;
surf(X_grid, Y_grid, sigma_vm_grid, 'EdgeColor', 'none'); 
view(2); colorbar; title('等效应力云图 (Pa)');

figure;
surf(X_grid, Y_grid, epsilon_vm_grid, 'EdgeColor', 'none'); 
view(2); colorbar; title('等效应变云图');

max_disp = max(disp_magnitude);
min_disp = min(disp_magnitude);
max_sigma_vm = max(sigma_vm);
min_sigma_vm = min(sigma_vm);
max_epsilon_vm = max(epsilon_vm);
min_epsilon_vm = min(epsilon_vm);
fprintf('总位移最大值: %.4e m\n', max_disp);
fprintf('总位移最小值: %.4e m\n\n', min_disp);
fprintf('等效应力最大值: %.4e Pa\n', max_sigma_vm);
fprintf('等效应力最小值: %.4e Pa\n\n', min_sigma_vm);
fprintf('等效应变最大值: %.4e\n', max_epsilon_vm);
fprintf('等效应变最小值: %.4e\n', min_epsilon_vm);