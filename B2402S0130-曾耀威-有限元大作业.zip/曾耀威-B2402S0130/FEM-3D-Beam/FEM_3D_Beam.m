% 基于MATLAB的三维八节点六面体单元(C3D8)有限元分析程序（三维悬臂梁）

function Main()
    % 读取inp文件获得节点坐标信息Nodes和单元信息Elements
    [Nodes, Elements] = Readmesh('Job-3D-Beam.inp');
    
    % 定义载荷 - x最大y最小的5个节点施加y方向-100N
    [~, xSortIdx] = sort(Nodes(:,1), 'descend'); 
    topXNodes = xSortIdx(1:30);  
    [~, ySortIdx] = sort(Nodes(topXNodes,2), 'ascend'); 
    loadNodes = topXNodes(ySortIdx(1:5));  
    Forces = [loadNodes, 2*ones(5,1), -100*ones(5,1)];  % [节点号, y方向(2), -100N]
    
    % 定义约束 - 找到x最小的30个节点  约束这些节点的x y z方向自由度
    [~, xSortIdx] = sort(Nodes(:,1), 'ascend');
    fixedNodes = xSortIdx(1:30); 
    Constraints = zeros(90, 3);  % 30个节点 × 3个方向
    for i = 1:30
        Constraints(3*i-2:3*i,:) = [fixedNodes(i) 1 0;  % x方向
                                fixedNodes(i) 2 0;  % y方向
                                fixedNodes(i) 3 0]; % z方向
    end
    
    % 材料参数
    E = 210000;    % 弹性模量
    u = 0.3;       % 泊松比
    
    % 求解位移、应力、应变
    [U, Stress, Strain] = StaticsSolver(E,u,Forces,Constraints,Nodes,Elements);
    
    % 输出结果
    OutputTXT = fopen('Results.txt','w');    % 打开一个写文件用于写入计算结果
    OutputResults(OutputTXT,Nodes,Elements,U,Stress,Strain) % 输出结果到文件-可视化
    fclose(OutputTXT);
    edit('Results.txt')
end


% 读取inp文件模型信息
function [Nodes, Elements] = Readmesh(fname)
    fid = fopen(fname, 'rt');
    S = textscan(fid, '%s', 'Delimiter', '\n');
    S = S{1};
    
    idxS = strfind(S, 'Node');
    idx1 = find(not(cellfun(@isempty, idxS)));
    
    idxS = strfind(S, 'Element'); 
    idx2 = find(not(cellfun(@isempty, idxS)));
    
    idxS = strfind(S, 'Nset');
    idx3 = find(not(cellfun(@isempty, idxS)));
    
    Nodes = S(idx1(1)+1:idx2(1)-1);
    Nodes = cell2mat(cellfun(@str2num, Nodes, 'UniformOutput', false));
    
    elements = S(idx2+1:idx3(1)-1);
    Elements = cell2mat(cellfun(@str2num, elements, 'UniformOutput', false));
    
    Nodes = Nodes(:,2:end);
    Elements = Elements(:,2:end);
end


% 一个八节点六面体单元求解器(求解位移矩阵、应力矩阵、应变矩阵)
function [U, Stress, Strain] = StaticsSolver(E, u, Forces, Constraints, Nodes, Elements)
    Dof = 3;  % 自由度
    NodeCount = size(Nodes, 1);  % 节点数量
    ElementCount = size(Elements, 1);  % 单元数量
    Dofs = Dof * NodeCount;  % 总自由度
    
    U = sparse(Dofs, 1);  % 初始化结构位移
    K = sparse(Dofs, Dofs);  % 初始化刚度矩阵
    Force = sparse(Dofs, 1);  % 初始化载荷向量
    
    % 计算应力-应变矩阵D
    D = LinearIsotropicD(E, u);
    
    % 组装总刚度矩阵
    for I = 1:ElementCount
        % 计算单元刚度矩阵
        ElementStiffnessMatrix = Ke(D, Nodes(Elements(I,:), 1), Nodes(Elements(I,:), 2), Nodes(Elements(I,:), 3));
        
        % 计算单元节点自由度编号
        ElementNodeDOF = zeros(1, 24);
        for J = 1:8
            II = (J-1) * Dof + 1;
            ElementNodeDOF(II:II+2) = (Elements(I,J)-1) * Dof + 1:(Elements(I,J)-1) * Dof + 3;
        end
        
        % 组装总刚
        K(ElementNodeDOF, ElementNodeDOF) = K(ElementNodeDOF, ElementNodeDOF) + ElementStiffnessMatrix;
    end

    % 施加载荷
    if size(Forces, 1) > 0
        ForceDOF = Dof * (Forces(:,1)-1) + Forces(:,2);   % 载荷作用自由度编号
        Force(ForceDOF) = Force(ForceDOF) + Forces(:,3);
    end
    
    % 施加位移约束
    BigNumber = 1e8;
    ConstraintsNumber = size(Constraints, 1);
    if ConstraintsNumber ~= 0
        FixedDof = Dof * (Constraints(:,1)-1) + Constraints(:,2);  % 约束自由度编号
        for i = 1:ConstraintsNumber
            K(FixedDof(i), FixedDof(i)) = K(FixedDof(i), FixedDof(i)) * BigNumber;
            Force(FixedDof(i)) = Constraints(i,3) * K(FixedDof(i), FixedDof(i));
        end
    end
    
    % 求解位移
    U = K\Force;
    
    % 初始化应力应变矩阵
    Stress = zeros(ElementCount, 6); % 每个单元的6个应力分量[σxx, σyy, σzz, τxy, τyz, τxz]
    Strain = zeros(ElementCount, 6); % 每个单元的6个应变分量[εxx, εyy, εzz, γxy, γyz, γxz]
    
    % 对每个单元计算应力和应变
    for i = 1:ElementCount
        % 获取单元节点坐标
        elementNodes = Elements(i,:);
        nodeCoords = Nodes(elementNodes, :);
        
        % 获取单元节点位移
        elementDof = zeros(1, 24);
        for j = 1:8
            elementDof(3*j-2:3*j) = 3*elementNodes(j)-2:3*elementNodes(j);
        end
        elementDisp = U(elementDof);
        
        % 在高斯点计算应变和应力
        [B, ~] = BMatrix(nodeCoords(:,1), nodeCoords(:,2), nodeCoords(:,3), 0, 0, 0);
        
        % 计算应变 ε = B * u
        strain = B * elementDisp;
        Strain(i,:) = strain';
        
        % 计算应力 σ = D * ε
        stress = D * strain;
        Stress(i,:) = stress';
    end
    
    % 使应力应变可视化效果更加流畅
    % 计算节点应力应变
    NodeStress = zeros(size(Nodes,1), 6);
    NodeStrain = zeros(size(Nodes,1), 6);
    NodeCount = zeros(size(Nodes,1), 1);
    
    % 将单元的应力应变值累加到相连的节点上
    for i = 1:size(Elements,1)
        nodeIds = Elements(i,:);
        for j = 1:length(nodeIds)
            NodeStress(nodeIds(j),:) = NodeStress(nodeIds(j),:) + Stress(i,:);
            NodeStrain(nodeIds(j),:) = NodeStrain(nodeIds(j),:) + Strain(i,:);
            NodeCount(nodeIds(j)) = NodeCount(nodeIds(j)) + 1;
        end
    end
    
    % 计算平均值
    for i = 1:size(Nodes,1)
        if NodeCount(i) > 0
            NodeStress(i,:) = NodeStress(i,:) / NodeCount(i);
            NodeStrain(i,:) = NodeStrain(i,:) / NodeCount(i);
        end
    end
    
    % 更新返回值
    Stress = NodeStress;
    Strain = NodeStrain;
end

% 计算单元刚度矩阵
function k=Ke(D,xe,ye,ze)
    %---------------------------------------------------------------
    kesi_yita = [-1/sqrt(3),-1/sqrt(3),-1/sqrt(3)
                     1/sqrt(3),-1/sqrt(3),-1/sqrt(3)
                     1/sqrt(3),1/sqrt(3),-1/sqrt(3)
                     -1/sqrt(3),1/sqrt(3),-1/sqrt(3)
                     -1/sqrt(3),-1/sqrt(3),1/sqrt(3)
                     1/sqrt(3),-1/sqrt(3),1/sqrt(3)
                     1/sqrt(3),1/sqrt(3),1/sqrt(3)
                     -1/sqrt(3),1/sqrt(3),1/sqrt(3)];
    w = [1,1];
    ww = [w(1)*w(1)*w(1),w(2)*w(1)*w(1),w(1)*w(1)*w(1),w(1)*w(2)*w(1),w(1)*w(1)*w(2),...
            w(2)*w(1)*w(2),w(1)*w(1)*w(2),w(1)*w(2)*w(2)];
    
    k = zeros(24,24);
    for i = 1:8
        % 单元节点坐标存储
        xyz=zeros(8,3);
        for j = 1:8
            xyz(j,1)=xe(j);
            xyz(j,2)=ye(j);
            xyz(j,3)=ze(j);
        end
        r = kesi_yita(i,1);
        s = kesi_yita(i,2);
        t = kesi_yita(i,3);
        [J B] = C3D8_cal_B(r,s,t,xyz);
        k = k+ww(i)*B'*D*B*det(J);
    end
end

% 计算C3D8单元的雅可比矩阵J和应变-位移矩阵B
function [J B]=C3D8_cal_B(r,s,t,xyz)
    % 计算形函数对自然坐标的导数矩阵 Nrst
    % 每一行分别对应 ∂N/∂r, ∂N/∂s, ∂N/∂t
    Nrst=0.125*[-(1-s)*(1-t) (1-s)*(1-t) (1+s)*(1-t) -(1+s)*(1-t) -(1-s)*(1+t)...
                (1-s)*(1+t) (1+s)*(1+t) -(1+s)*(1+t);
                -(1-r)*(1-t) -(1+r)*(1-t) (1+r)*(1-t) (1-r)*(1-t) -(1-r)*(1+t)...
                -(1+r)*(1+t) (1+r)*(1+t) (1-r)*(1+t);
                -(1-r)*(1-s) -(1+r)*(1-s) -(1+r)*(1+s) -(1-r)*(1+s) (1-r)*(1-s)...
                (1+r)*(1-s) (1+r)*(1+s) (1-r)*(1+s)];
    
    % 计算雅可比矩阵
    J = Nrst * xyz;
    
    % 计算雅可比矩阵的逆
    R = inv(J);
    
    % 构建A矩阵,用于计算应变-位移矩阵
    A = [R(1,1) R(1,2) R(1,3) 0 0 0 0 0 0;
         0 0 0 R(2,1) R(2,2) R(2,3) 0 0 0;
         0 0 0 0 0 0 R(3,1) R(3,2) R(3,3);
         0 0 0 R(3,1) R(3,2) R(3,3) R(2,1) R(2,2) R(2,3);
         R(3,1) R(3,2) R(3,3) 0 0 0 R(1,1) R(1,2) R(1,3);
         R(2,1) R(2,2) R(2,3) R(1,1) R(1,2) R(1,3) 0 0 0];
    
    % 提取形函数导数的各个分量
    N1r = Nrst(1,1); N1s = Nrst(2,1); N1t = Nrst(3,1);
    N2r = Nrst(1,2); N2s = Nrst(2,2); N2t = Nrst(3,2);
    N3r = Nrst(1,3); N3s = Nrst(2,3); N3t = Nrst(3,3);
    N4r = Nrst(1,4); N4s = Nrst(2,4); N4t = Nrst(3,4);
    N5r = Nrst(1,5); N5s = Nrst(2,5); N5t = Nrst(3,5);
    N6r = Nrst(1,6); N6s = Nrst(2,6); N6t = Nrst(3,6);
    N7r = Nrst(1,7); N7s = Nrst(2,7); N7t = Nrst(3,7);
    N8r = Nrst(1,8); N8s = Nrst(2,8); N8t = Nrst(3,8);
    
    % 构建G矩阵,包含所有节点的形函数导数
    G = [N1r 0 0 N2r 0 0 N3r 0 0 N4r 0 0 N5r 0 0 N6r 0 0 N7r 0 0 N8r 0 0;
         N1s 0 0 N2s 0 0 N3s 0 0 N4s 0 0 N5s 0 0 N6s 0 0 N7s 0 0 N8s 0 0;
         N1t 0 0 N2t 0 0 N3t 0 0 N4t 0 0 N5t 0 0 N6t 0 0 N7t 0 0 N8t 0 0;
         0 N1r 0 0 N2r 0 0 N3r 0 0 N4r 0 0 N5r 0 0 N6r 0 0 N7r 0 0 N8r 0;
         0 N1s 0 0 N2s 0 0 N3s 0 0 N4s 0 0 N5s 0 0 N6s 0 0 N7s 0 0 N8s 0;
         0 N1t 0 0 N2t 0 0 N3t 0 0 N4t 0 0 N5t 0 0 N6t 0 0 N7t 0 0 N8t 0;
         0 0 N1r 0 0 N2r 0 0 N3r 0 0 N4r 0 0 N5r 0 0 N6r 0 0 N7r 0 0 N8r;
         0 0 N1s 0 0 N2s 0 0 N3s 0 0 N4s 0 0 N5s 0 0 N6s 0 0 N7s 0 0 N8s;
         0 0 N1t 0 0 N2t 0 0 N3t 0 0 N4t 0 0 N5t 0 0 N6t 0 0 N7t 0 0 N8t];
    
    % 计算最终的应变-位移矩阵B
    B = A * G;
end


%  计算六面体单元线弹性本构应力-应变矩阵
function [D] = LinearIsotropicD(E, u)
    D = E/((1+u)*(1-2*u)) * [1-u  u    u    0         0         0;
                             u    1-u  u    0         0         0;
                             u    u    1-u  0         0         0;
                             0    0    0    (1-2*u)/2  0         0;
                             0    0    0    0         (1-2*u)/2  0;
                             0    0    0    0         0         (1-2*u)/2];
end


% 计算B矩阵
function [B, J] = BMatrix(x, y, z, xi, eta, zeta)
    % 计算形函数导数
    dN = ShapeDerivatives(xi, eta, zeta);
    
    % 修改雅可比矩阵的计算方式
    % 将节点坐标组织成矩阵形式
    coords = [x y z];
    
    % 计算雅可比矩阵
    J = dN * coords;
    
    % 计算形函数对x,y,z的导数
    dNxyz = J\dN;
    
    % 构建B矩阵
    B = zeros(6,24);
    for i = 1:8
        idx = 3*i-2;
        B(1,idx)   = dNxyz(1,i);
        B(2,idx+1) = dNxyz(2,i);
        B(3,idx+2) = dNxyz(3,i);
        B(4,idx)   = dNxyz(2,i);
        B(4,idx+1) = dNxyz(1,i);
        B(5,idx+1) = dNxyz(3,i);
        B(5,idx+2) = dNxyz(2,i);
        B(6,idx)   = dNxyz(3,i);
        B(6,idx+2) = dNxyz(1,i);
    end
end

% 计算形函数导数
function dN = ShapeDerivatives(xi, eta, zeta)
    % 八节点六面体单元的形函数导数
    dN = zeros(3,8);
    
    % ∂N/∂ξ
    dN(1,1) = -0.125*(1-eta)*(1-zeta);
    dN(1,2) =  0.125*(1-eta)*(1-zeta);
    dN(1,3) =  0.125*(1+eta)*(1-zeta);
    dN(1,4) = -0.125*(1+eta)*(1-zeta);
    dN(1,5) = -0.125*(1-eta)*(1+zeta);
    dN(1,6) =  0.125*(1-eta)*(1+zeta);
    dN(1,7) =  0.125*(1+eta)*(1+zeta);
    dN(1,8) = -0.125*(1+eta)*(1+zeta);
    
    % ∂N/∂η
    dN(2,1) = -0.125*(1-xi)*(1-zeta);
    dN(2,2) = -0.125*(1+xi)*(1-zeta);
    dN(2,3) =  0.125*(1+xi)*(1-zeta);
    dN(2,4) =  0.125*(1-xi)*(1-zeta);
    dN(2,5) = -0.125*(1-xi)*(1+zeta);
    dN(2,6) = -0.125*(1+xi)*(1+zeta);
    dN(2,7) =  0.125*(1+xi)*(1+zeta);
    dN(2,8) =  0.125*(1-xi)*(1+zeta);
    
    % ∂N/∂ζ
    dN(3,1) = -0.125*(1-xi)*(1-eta);
    dN(3,2) = -0.125*(1+xi)*(1-eta);
    dN(3,3) = -0.125*(1+xi)*(1+eta);
    dN(3,4) = -0.125*(1-xi)*(1+eta);
    dN(3,5) =  0.125*(1-xi)*(1-eta);
    dN(3,6) =  0.125*(1+xi)*(1-eta);
    dN(3,7) =  0.125*(1+xi)*(1+eta);
    dN(3,8) =  0.125*(1-xi)*(1+eta);
end


%  输出六面体单元计算结果(输出txt文件和可视化)
function OutputResults(OutputTXT, Nodes, Elements, U, Stress, Strain)
    NodeCount = size(Nodes, 1);      % 节点数量
    ElementCount = size(Elements, 1); % 单元数量
    ElementNodeCount = 8;            % 每个单元节点数
    Dof = 3;                         % 自由度
    
    % 计算Umag位移矩阵
    Umag = zeros(NodeCount, 1);
    for i = 1:NodeCount
        Umag(i) = sqrt(U(3*i-2)^2 + U(3*i-1)^2 + U(3*i)^2);
    end
    
    % 将节点位移写入TXT中
    fprintf(OutputTXT, '\r\n Node          U1          U2          U3');
    for I = 1:NodeCount
        II = Dof*(I-1);
        fprintf(OutputTXT, '\r\n%5d %11.3e %11.3e %11.3e', I, U(II+1:II+3)+0);
    end
    fprintf(OutputTXT, '\r\n\r\n');
    fprintf(1, '\t\t *** 计算完成 ***\n');
    
    % 绘制变形前网格
    for i = 1:size(Elements, 1)
        points = Nodes(Elements(i,:), :);
        mesh = 1:8;                  % 网格信息
        % 生成六面体节点坐标
        vertices_matrix = [points(mesh(1,:),1), points(mesh(1,:),2), points(mesh(1,:),3)];
        % 生成六面体节点顺序
        faces_matrix = [1 2 6 5; 2 3 7 6; 3 4 8 7; 4 1 5 8; 1 2 3 4; 5 6 7 8]; % 定义每个面的节点编号
        patch('vertices', vertices_matrix, 'faces', faces_matrix, 'facecolor', 'g');
        view(3); 
        hold on                      % 绘图
    end
    axis equal
    alpha(1);
    
    % 绘制位移云图
    for i = 1:Dof                    % 绘制U1-U3
        PlotContour(Nodes, Elements, U, U(i:3:size(U,1)))
        title(['U', num2str(i)]);    % 设置云图标题
    end
    
    % 绘制Umag云图
    PlotContour(Nodes, Elements, U, Umag)
    title('Umag')
    
    % 输出应力结果
    fprintf(OutputTXT, '\r\n\r\n Element     σxx        σyy        σzz        τxy        τyz        τxz');
    for i = 1:size(Elements,1)
        fprintf(OutputTXT, '\r\n%5d %11.3e %11.3e %11.3e %11.3e %11.3e %11.3e', ...
            i, Stress(i,1), Stress(i,2), Stress(i,3), Stress(i,4), Stress(i,5), Stress(i,6));
    end
    
    % 输出应变结果
    fprintf(OutputTXT, '\r\n\r\n Element     εxx        εyy        εzz        γxy        γyz        γxz');
    for i = 1:size(Elements,1)
        fprintf(OutputTXT, '\r\n%5d %11.3e %11.3e %11.3e %11.3e %11.3e %11.3e', ...
            i, Strain(i,1), Strain(i,2), Strain(i,3), Strain(i,4), Strain(i,5), Strain(i,6));
    end
    
    % 绘制von Mises应力云图
    vonMises = sqrt(0.5*((Stress(:,1)-Stress(:,2)).^2 + ...
                        (Stress(:,2)-Stress(:,3)).^2 + ...
                        (Stress(:,3)-Stress(:,1)).^2 + ...
                        6*(Stress(:,4).^2 + Stress(:,5).^2 + Stress(:,6).^2)));
    
    PlotContour(Nodes, Elements, U, vonMises)
    title('von Mises Stress')
    
    % 绘制应力云图
    stress_names = {'σxx', 'σyy', 'σzz', 'τxy', 'τyz', 'τxz'};
    for i = 1:6
        PlotContour(Nodes, Elements, U, Stress(:,i))
        title(['Stress ', stress_names{i}])
    end
    
    % 绘制应变云图
    strain_names = {'εxx', 'εyy', 'εzz', 'γxy', 'γyz', 'γxz'};
    for i = 1:6
        PlotContour(Nodes, Elements, U, Strain(:,i))
        title(['Strain ', strain_names{i}])
    end
end


%  绘制六面体单元云图 可视化
function PlotContour(Nodes, Elements, U, Component)
    NodeCount = size(Nodes, 1);          % 节点数量
    ElementCount = size(Elements, 1);     % 单元数量
    ElementNodeCount = 8;                 % 每个单元节点数
    
    % 矩阵初始化：X Y Z坐标和value值,用每个单元最终节点坐标绘制云图
    X = zeros(ElementNodeCount, ElementCount);
    Y = zeros(ElementNodeCount, ElementCount);
    Z = zeros(ElementNodeCount, ElementCount);
    value = zeros(ElementNodeCount, ElementCount);
    
    % 计算变形后的节点坐标
    DeformationCoefficient = 5.0e2;      % 变形放大系数
    deformedNodes = Nodes + reshape(U, 3, [])' * DeformationCoefficient;
    
    % 判断Component是节点值还是单元值
    isNodeValue = (length(Component) == NodeCount);
    
    % 对每个单元进行处理
    for i = 1:ElementCount
        nd = Elements(i, :);
        X(:,i) = deformedNodes(nd, 1);
        Y(:,i) = deformedNodes(nd, 2);
        Z(:,i) = deformedNodes(nd, 3);
        
        % 所有结果都作为节点值处理
        value(:,i) = Component(nd);
    end
    
    % 设置colormap的颜色
    myColor = 1/255 * [0,0,255;    0,93,255;   0,185,255;  0,255,232;
                       0,255,139;   0,255,46;   46,255,0;   139,255,0;
                       232,255,0;   255,185,0;  255,93,0;   255,0,0];
    
    % 绘制云图
    figure
    for i = 1:ElementCount
        xyz = [X(:,i) Y(:,i) Z(:,i)];
        if ElementNodeCount == 8  % C3D8单元
            faces = [1 2 6 5; 2 3 7 6; 3 4 8 7; 4 1 5 8; 1 2 3 4; 5 6 7 8];
        end
        patch('Vertices', xyz, 'Faces', faces, ...
              'FaceVertexCData', value(:,i), 'FaceColor', 'interp');
        hold on
    end
    
    view(3);
    rotate3d on;
    axis off;                                         % 不显示坐标轴
    colormap(myColor);
    caxis([min(Component), max(Component)]);
    t1 = caxis;
    t1 = linspace(t1(1), t1(2), 13);
    colorbar('ytick', t1, 'Location', 'westoutside');
    axis equal;
end
