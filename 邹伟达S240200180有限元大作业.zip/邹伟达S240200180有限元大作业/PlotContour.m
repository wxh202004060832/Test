
function PlotContour(Nodes,Elements,U,Component)
NodeCount = size(Nodes,1) ;
ElementCount = size(Elements,1) ;
ElementNodeCount=8;
X = zeros(ElementNodeCount,ElementCount) ;
Y = zeros(ElementNodeCount,ElementCount) ;
Z = zeros(ElementNodeCount,ElementCount) ;
value = zeros(ElementNodeCount,ElementCount) ;
if size(Component,1)>1
    for i=1:ElementCount
        nd=Elements(i,:);
        value(:,i) = Component(nd) ;
    end
else
    Difference=max(Component)-min(Component);
    AVG=0.75;
    for i=1:1:NodeCount
        TElements=Elements';
        itemp=(TElements==i);
        Cut=max(Component(1,itemp))-min(Component(1,itemp));
        if 0<Cut&&Cut<=AVG*Difference(1)
            Component(1,itemp)=mean(Component(1,itemp));
        end
    end
    value=reshape(Component,ElementNodeCount,ElementCount);
end
myColor=1/255*[0,0,255;  0,93,255;   0,185,255;  0,255,232;
    0,255,139;  0,255,46;  46,255,0;  139,255,0;
    232,255,0;  255,185,0; 255,93,0;  255,0,0];
newNodes=Nodes';
newNodes=newNodes(:);
DeformationCoefficient=5.0e2;
DeformationCoefficient=1;
newNodes=newNodes+DeformationCoefficient*U;
newNodes=reshape(newNodes,[3,size(Nodes,1)]);
newNodes=newNodes';
if ElementNodeCount == 4
    fm = [1 2 4;2 3 4;3 1 4;1 3 2]; 
elseif ElementNodeCount==6
    fm=[1 2 3 1;4 5 6 4;1 2 5 4;1 3 6 4;2 3 6 5];
elseif ElementNodeCount == 8
    fm = [1 2 6 5; 2 3 7 6; 3 4 8 7; 4 1 5 8; 1 2 3 4; 5 6 7 8];
elseif ElementNodeCount == 20
    fm = [1,9,2,10,3,11,4,12;5,13,6,14,7,15,8,16;1,9,2,18,6,13,5,17;
        2,10,3,19,7,14,6,18;3,11,4,20,8,15,7,19;1,17,5,16,8,20,4,12]; 
end
xyz = cell(1,ElementCount) ;
profile = xyz ;
for e=1:ElementCount
    nd=Elements(e,:);
    X = newNodes(nd,1) ;
    Y = newNodes(nd,2) ;
    Z = newNodes(nd,3) ;
    xyz{e} = [X  Y Z] ;
    profile{e} = value(:,e);
end
figure
cellfun(@patch,repmat({'Vertices'},1,ElementCount),xyz,.......
    repmat({'Faces'},1,ElementCount),repmat({fm},1,ElementCount),......
    repmat({'FaceVertexCdata'},1,ElementCount),profile,......
    repmat({'FaceColor'},1,ElementCount),repmat({'interp'},1,ElementCount));
view(3);
rotate3d on;
axis off;
colormap(myColor);
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis equal;
end