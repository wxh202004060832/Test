
function OutputResults(Nodes,Elements,D,U)
NodeCount = size(Nodes,1) ;
ElementCount= size(Elements,1);
ElementNodeCount=8;
Dof=3;
[NodeStrain,NodeStress,GaussStrain,GaussStress]=CalculateStrainAndStress(U,D,Nodes,Elements);
MISES=zeros(1,ElementCount*ElementNodeCount);
for I=1:ElementCount*ElementNodeCount
    MISES(I)=sqrt(0.5)*sqrt((NodeStress(1,I)-NodeStress(2,I))^2+(NodeStress(1,I)-NodeStress(3,I))^2+....
        (NodeStress(2,I)-NodeStress(3,I))^2+6*(NodeStress(4,I)^2+NodeStress(5,I)^2+NodeStress(6,I)^2));
    Emax(I)=sqrt(0.5)*sqrt((NodeStrain(1,I)-NodeStrain(2,I))^2+(NodeStrain(1,I)-NodeStrain(3,I))^2+....
        (NodeStrain(2,I)-NodeStrain(3,I))^2+6*(NodeStrain(4,I)^2+NodeStrain(5,I)^2+NodeStrain(6,I)^2));
end
Umag=zeros(NodeCount,1);
for i=1:NodeCount
    Umag(i)=sqrt(U(3*i-2)^2+U(3*i-1)^2+U(3*i)^2);
end
PlotContour(Nodes,Elements,U,Umag)
title('Umag')
PlotContour(Nodes,Elements,U,MISES)
title('MISES')
PlotContour(Nodes,Elements,U,MISES/70e9)
title('Emax')
end