function [Ke]=Ke(EleNodeCoord, D)
% �ú�������C3D4��Ԫ�նȾ���
[dNdx, JacobiDET] = ShapeFunction(EleNodeCoord);
Coefficient=1/6*JacobiDET; % 1/6 Hammer����Ȩϵ��
B=zeros(6, 12);
for I=1:4
    COL=(I-1)*3+1:(I-1)*3+3;
    B(:, COL)=[dNdx(1, I)       0                0         ;
               0                dNdx(2, I)       0         ;
               0                0                dNdx(3, I);
               dNdx(2, I)       dNdx(1, I)       0         ;
               0                dNdx(3, I)       dNdx(2, I);
               dNdx(3, I)       0                dNdx(1, I)];
end
Ke=Coefficient*B'*D*B;
end