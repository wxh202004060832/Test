%% 有限元求解平面问题
% 程序计算思路：导入已经剖分好的网格、求单元刚度矩阵、集成总体刚度矩阵、求解位移、回代求解应力。
close all;
clear;
clc;
 
%% 根据外部提供的网格inp文件进行计算求解
t=0.05;
E=210e5;
mu=0.3;
F=1e6; %参数输入使用“米-帕”单位制
filename="Job-3.inp";
[Node_info,Ele_info]=read_inp_file(filename);
[K,D,BB]=Assembly(Node_info,Ele_info,E,mu,t); %求解单刚并进行总刚与“总应变矩阵”的组装
R=Load(Node_info,F); %节点等效载荷
[KK,RR]=BC(Node_info,K,R); %引入边界条件消除总刚奇异性 
u=lsqminnorm(KK,RR); %求解节点位移
[sigma_x,sigma_y,sigma_xy]=Stress(BB,Ele_info,D,u); %求单元应力
Plot_u(u,Node_info,Ele_info); %绘制位移分布云图
stress_name1="sigma_x";
stress_name2="sigma_y";
stress_name3="sigma_xy";
sigma_x_node=Plot_stress_node(sigma_x,Node_info,Ele_info,stress_name1); %绘制 sigma_x 应力云图，并输出节点平均应力值
sigma_y_node=Plot_stress_node(sigma_y,Node_info,Ele_info,stress_name2); %绘制 sigma_y 应力云图，并输出节点平均应力值
sigma_xy_node=Plot_stress_node(sigma_xy,Node_info,Ele_info,stress_name3); %绘制 sigma_xy 应力云图，并输出节点平均应力值
Mise_stress(Node_info,Ele_info,sigma_x_node,sigma_y_node,sigma_xy_node); %绘制 Mises 应力云图
 
%% 网格导入函数（根据inp文件导入包含节点编号、节点坐标的节点信息与包含单元编号、单元包含节点编号的单元信息）
function [nodeinfo, eleinfo] = read_inp_file(filename)
% 读取ABAQUS INP文件中的节点和三角形单元信息
% 输入参数：
%   filename - INP文件名（含路径）
% 输出参数：
%   nodeinfo - N×3矩阵，格式为 [节点ID, X坐标, Y坐标]
%   eleinfo  - M×4矩阵，格式为 [单元ID, 节点1ID, 节点2ID, 节点3ID]

% 初始化存储变量
nodeinfo = [];
eleinfo = [];

% 打开文件
fid = fopen(filename, 'r');
if fid == -1
    error('无法打开文件: %s', filename);
end

% 状态标志
reading_nodes = false;
reading_elements = false;

% 逐行读取文件
while ~feof(fid)
    line = strtrim(fgetl(fid));  % 读取并去除首尾空格
    
    % 跳过空行
    if isempty(line)
        continue
    end
    
    % 检查节点头
    if startsWith(line, '*Node')
        reading_nodes = true;
        reading_elements = false;
        continue
    end
    
    % 检查单元头（仅处理三角形单元）
    if startsWith(line, '*Element') && contains(line, 'type=S3') || ...
       startsWith(line, '*Element') && contains(line, 'type=CPE3') || ...
       startsWith(line, '*Element') && contains(line, 'type=STRI65')
        reading_elements = true;
        reading_nodes = false;
        continue
    end
    
    % 遇到下一个节点头则停止读取
    if startsWith(line, '*') && ~startsWith(line, '**')
        reading_nodes = false;
        reading_elements = false;
    end
    
    % 读取节点数据
    if reading_nodes
        % 使用textscan处理带逗号分隔的数据
          nodeData = sscanf(line, '%d,%f,%f');
            if numel(nodeData) == 3
                nodeinfo = [nodeinfo; nodeData'];
            end
    end
    
    % 读取单元数据
    if reading_elements
        % 使用sscanf处理不同分隔符（逗号或空格）
        data = sscanf(line, '%d,%d,%d,%d')';
        if isempty(data)
            data = sscanf(line, '%d %d %d %d')';
        end
        if length(data) == 4
            eleinfo = [eleinfo; data];
        end
    end
end

% 关闭文件
fclose(fid);

% 按ID排序
if ~isempty(nodeinfo)
    nodeinfo = sortrows(nodeinfo, 1);
end
if ~isempty(eleinfo)
    eleinfo = sortrows(eleinfo, 1);
end

% 验证数据完整性
if isempty(nodeinfo)
    warning('未找到节点信息！');
end
if isempty(eleinfo)
    warning('未找到三角形单元信息！');
end
end
 
%% 整体刚度矩阵集成函数 （输入节点、单元信息，输出总刚、修改后的应变矩阵）
function [K,D,BB]=Assembly(Node_info,Ele_info,E,mu,t)
Num_nodes=size(Node_info,1);
Num_eles=size(Ele_info,1);
K=zeros(2*Num_nodes);
BB=[];
for i=1:Num_eles
 node_info_local=[Ele_info(i,2),Node_info(Ele_info(i,2),2),Node_info(Ele_info(i,2),3);
 Ele_info(i,3),Node_info(Ele_info(i,3),2),Node_info(Ele_info(i,3),3);
 Ele_info(i,4),Node_info(Ele_info(i,4),2),Node_info(Ele_info(i,4),3)];
 %3x3 的矩阵，第一列为节点编号，二、三列为节点横、纵坐标
 [ke,D,B]=Ke(node_info_local,E,mu,t);
 BB=[BB;B]; 
 j=node_info_local(1,1);
 k=node_info_local(2,1);
 m=node_info_local(3,1);
 num=[2*j-1,2*j,2*k-1,2*k,2*m-1,2*m];
 for n1=1:6
 for n2=1:6
 K(num(n1),num(n2))=K(num(n1),num(n2))+ke(n1,n2);
 end
 end
end
end 
 
%% 单元刚度矩阵计算函数 （输入节点、单元信息，输出单刚、弹性矩阵、应变矩阵）
function [ke,D,B]=Ke(node_info,E,mu,t)
C=[1,node_info(1,2),node_info(1,3);
 1,node_info(2,2),node_info(2,3);
 1,node_info(3,2),node_info(3,3)];
A=0.5*det(C);
B=0.5/A*[node_info(2,3)-node_info(3,3),0,node_info(3,3)-node_info(1,3),0,node_info(1,3)-node_info(2,3),0;
 0,node_info(3,2)-node_info(2,2),0,node_info(1,2)-node_info(3,2),0,node_info(2,2)-node_info(1,2);
 node_info(3,2)-node_info(2,2),node_info(2,3)-node_info(3,3),node_info(1,2)-node_info(3,2),...
 node_info(3,3)-node_info(1,3),node_info(2,2)-node_info(1,2),node_info(1,3)-node_info(2,3)];
D=E/(1-mu^2)*[1,mu,0;
 mu,1,0;
 0,0,(1-mu)/2];
ke=B'*D*B*A*t;
end
 
%% 节点载荷列阵
function R=Load(Node_info,F)
R=zeros(size(Node_info,1)*2,1);
%对节点id为num1赋予载荷
num1 = 33;
R(2*num1)=-F/2;
end
 
%% 引入边界条件，修改总刚和载荷列阵 （划一置零法）
function [KK,RR]=BC(Node_info,K,R)
num=find(Node_info(:,2)+100<1e-9); %固定最左端的节点 其x坐标为-100
KK=K;
RR=R;
for i=1:size(num,1)
 r=num(i);
 KK(2*r-1,:)=0;
 KK(:,2*r-1)=0;
 KK(2*r-1,2*r-1)=1;
 KK(2*r,:)=0;
 KK(:,2*r)=0;
 KK(2*r,2*r)=1;
 RR(2*r-1)=0;
 RR(2*r)=0;
end
end
 
%% 单元应力计算函数 （输入应变总矩阵、单元总信息、计算得到的位移解，输出每个单元的应力）
function [sigma_x,sigma_y,sigma_xy]=Stress(BB,Ele_info,D,u)
Num_eles=size(Ele_info,1);
sigma=[];
sigma_x=[];
sigma_y=[];
sigma_xy=[];
for i=1:Num_eles
 node_local=Ele_info(i,2:4);
 u_local=[u(2*node_local(1)-1);
 u(2*node_local(1));
 u(2*node_local(2)-1);
 u(2*node_local(2));
 u(2*node_local(3)-1);
 u(2*node_local(3))];
 sigma=D*BB(3*i-2:3*i,:)*u_local;
 sigma_x=[sigma_x;sigma(1)];
 sigma_y=[sigma_y;sigma(2)];
 sigma_xy=[sigma_xy;sigma(3)];
end
end
 
%% 后处理函数 绘制节点位移云图
function []=Plot_u(u, Node_info, eleinfo)
    % 提取位移分量
    u1 = [];  % x方向的位移
    u2 = [];  % y方向的位移
    for i = 1:size(Node_info, 1)  % Node_info的大小
        u1 = [u1; u(2*i-1)];  % x方向的位移
        u2 = [u2; u(2*i)];    % y方向的位移
    end
    
    % 计算变形后的节点坐标
    new_node = Node_info(:, 2:3) + [u1, u2];  % 变形后的节点坐标 (x + u1, y + u2)

    % 绘制变形前后的形状
    figure;
    % 绘制原始网格
    patch('Faces', eleinfo(:, 2:4), 'Vertices', Node_info(:, 2:3), 'FaceColor', 'none', 'EdgeColor', 'g');
    % 绘制变形后的网格
    hold on;
    patch('Faces', eleinfo(:, 2:4), 'Vertices', new_node, 'FaceColor', 'none', 'EdgeColor', 'b');
    
    % 图形美化
    xlabel('x');
    ylabel('y');
    title('位移结果：变形前后');
    axis equal;
    grid on;
    legend('原始网格', '变形网格');
    hold off;

    % 绘制网格
    figure;
    hold on;
    % 使用 patch 绘制三角形面片，并将每个面片的颜色与应力值相关联
    % 'FaceVertexCData' 用于设置每个面片的颜色，'CData' 是节点应力的平均值
    patch('Faces', eleinfo(:, 2:4), 'Vertices', Node_info(:, 2:3), ...
          'FaceVertexCData', u1, 'FaceColor', 'flat', ...
          'EdgeColor', 'k');  % 使用应力值为每个面片着色

    % 添加图形美化
    xlabel('x');
    ylabel('y');
    title('x位移分布云图/Pa');
    axis equal;
    % shading interp;  % 色彩平滑会消除网格线
    colorbar;  % 显示色条
    box on;

    % 绘制网格
    figure;
    hold on;
    % 使用 patch 绘制三角形面片，并将每个面片的颜色与应力值相关联
    % 'FaceVertexCData' 用于设置每个面片的颜色，'CData' 是节点应力的平均值
    patch('Faces', eleinfo(:, 2:4), 'Vertices', Node_info(:, 2:3), ...
          'FaceVertexCData', u2, 'FaceColor', 'flat', ...
          'EdgeColor', 'k');  % 使用应力值为每个面片着色

    % 添加图形美化
    xlabel('x');
    ylabel('y');
    title('y位移分布云图/Pa');
    axis equal;
    % shading interp;  % 色彩平滑会消除网格线
    colorbar;  % 显示色条
    box on;

    % 初始化位移矩阵
    dis = zeros(size(Node_info, 1), 2);  % 每个节点有两个自由度 (x, y)
    Magnitude = zeros(size(Node_info, 1), 1);  % 初始化 Magnitude 向量

    % 计算每个节点的位移和位移大小
    for i = 1:size(Node_info, 1)
        % 计算x方向和y方向的位移变化
        dis(i, 1) = new_node(i, 1) - Node_info(i, 2);  % x方向位移
        dis(i, 2) = new_node(i, 2) - Node_info(i, 3);  % y方向位移
        
        % 计算位移大小（Magnitude）
        Magnitude(i) = sqrt(dis(i, 1)^2 + dis(i, 2)^2);  % 计算位移的大小
    end

    % 绘制网格
    figure;
    hold on;
    % 使用 patch 绘制三角形面片，并将每个面片的颜色与应力值相关联
    % 'FaceVertexCData' 用于设置每个面片的颜色，'CData' 是节点应力的平均值
    patch('Faces', eleinfo(:, 2:4), 'Vertices', Node_info(:, 2:3), ...
          'FaceVertexCData', Magnitude, 'FaceColor', 'flat', ...
          'EdgeColor', 'k');  % 使用应力值为每个面片着色

    % 添加图形美化
    xlabel('x');
    ylabel('y');
    title('Magnitude位移分布云图/Pa');
    axis equal;
    %shading interp;  % 色彩平滑会消除网格线
    colorbar;  % 显示色条
    box on;


end

%% 后处理函数 绘制 sigma 云图
%每一个节点的应力值取周围单元的应力平均值
function sigma_xx_node = Plot_stress_node(sigma_x, Node_info, Ele_info,name)
    % 初始化一个空的应力向量
    sigma_x_node = [];

    % 计算每个节点的平均应力值
    for i = 1:size(Node_info, 1)
        % 找到与节点 i 相关的所有单元
        E = [];
        E1 = find(abs(Ele_info(:, 2) - i) < 1e-9);  % 查找单元中包含节点 i 的单元
        E2 = find(abs(Ele_info(:, 3) - i) < 1e-9);
        E3 = find(abs(Ele_info(:, 4) - i) < 1e-9);
        E = [E; E1; E2; E3];  % 合并相关单元
        n = size(E, 1);  % 计算与节点 i 相关的单元数
        sx_sum = 0;  % 初始化应力总和
        
        for j = 1:n
            sx_sum = sx_sum + sigma_x(E(j));  % 累加每个单元的应力值
        end
        
        sigma_x_node = [sigma_x_node; sx_sum / n];  % 计算该节点的平均应力并存储
    end

    % 绘制网格
    figure;
    hold on;
    % 使用 patch 绘制三角形面片，并将每个面片的颜色与应力值相关联
    % 'FaceVertexCData' 用于设置每个面片的颜色，'CData' 是节点应力的平均值
    patch('Faces', Ele_info(:, 2:4), 'Vertices', Node_info(:, 2:3), ...
          'FaceVertexCData', sigma_x_node, 'FaceColor', 'flat', ...
          'EdgeColor', 'k');  % 使用应力值为每个面片着色

    % 添加图形美化
    xlabel('x');
    ylabel('y');
    if name=="sigma_x"
        title('\sigma_x 应力分布云图/Pa');
    end
    if(name=="sigma_y")
        title('\sigma_y 应力分布云图/Pa');
    end
    if(name=="sigma_xy")
        title('\sigma_x_y 应力分布云图/Pa');
    end
    axis equal;
    % shading interp;  % 色彩平滑会消除网格线
    colorbar;  % 显示色条
    box on;
    
    % 返回计算得到的应力值
    sigma_xx_node = sigma_x_node;  % 返回每个节点的应力值
end
 
%% 后处理函数 绘制 Mises 应力分布云图
function []=Mise_stress(Node_info,Ele_info,sigma_xx_node,sigma_yy_node,sigma_xxyy_node)
% 先求主应力
sigma_m=[];
for i=1:size(Node_info,1)
 sigma1=(sigma_xx_node(i)+sigma_yy_node(i))/2+0.5*sqrt((sigma_xx_node(i)-sigma_yy_node(i))^2+4*sigma_xxyy_node(i)*sigma_xxyy_node(i));
 sigma2=(sigma_xx_node(i)+sigma_yy_node(i))/2-0.5*sqrt((sigma_xx_node(i)-sigma_yy_node(i))^2+4*sigma_xxyy_node(i)*sigma_xxyy_node(i));
% 求 Von-Mise 等效应力
 sigma_m=[sigma_m;sqrt(sigma1^2+sigma2^2-sigma1*sigma2)];
end
sigma_mm=sigma_m; %将 sigma_m 的数值进行保护，后续标注会用到

  % 初始化一个空的应力向量
    sigma_x_node = sigma_mm;

    % 绘制网格
    figure;
    hold on;
    % 使用 patch 绘制三角形面片，并将每个面片的颜色与应力值相关联
    % 'FaceVertexCData' 用于设置每个面片的颜色，'CData' 是节点应力的平均值
    patch('Faces', Ele_info(:, 2:4), 'Vertices', Node_info(:, 2:3), ...
          'FaceVertexCData', sigma_x_node, 'FaceColor', 'flat', ...
          'EdgeColor', 'k');  % 使用应力值为每个面片着色

    % 添加图形美化
    xlabel('x');
    ylabel('y');
    title('Mise 应力分布云图/Pa');
    axis equal;
    % shading interp;  % 色彩平滑会消除网格线
    colorbar;  % 显示色条
    box on;
end