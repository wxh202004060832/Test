function bcnodes = read_bcnodes
% 本函数用于从inp文件中读取被施加约束的节点信息

fidin=fopen('model.inp');
i=1;
 while 1
        tline = fgetl(fidin);                           
        if strncmpi(tline,'*Nset, nset=SetBC, generate',27)==1   
            while 1
                tline=fgetl(fidin);
                if strncmpi(tline,'*Nset, nset=SetFORCE',20)==1
                    break
                end
                   bcnodes{i}=tline;
                   i=i+1;
            end
        end
        if strncmpi(tline,'*END',4)==1
            break
        end
 end
bcnodes=bcnodes';
bcnodes=cell2mat(bcnodes);
bcnodes=str2num(bcnodes);
end