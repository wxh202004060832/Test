function NODES = read_nodes
% 本函数用于从inp文件中读取每个单元的节点信息

fidin=fopen('model.inp');
i=1;
 while 1
        tline = fgetl(fidin);                           
        if strncmpi(tline,'*Element, type=C3D8R',20)==1   
            while 1
                tline=fgetl(fidin);
                if strncmpi(tline,'*Nset, nset=Set-1, generate',27)==1
                    break
                end 
                   nodes{i}=tline;              
                   i=i+1;
            end
        end
        if strncmpi(tline,'*END',4)==1
            break
        end
 end
nodes=nodes';
NODES=cell2mat(nodes);
NODES=str2num(NODES);
NODES=NODES(:,2:9);
end