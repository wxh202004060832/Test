function result_inp(disp,node_strain,node_stress)
%本函数用于将模型的信息（节点信息、单元信息）和计算结果（位移、应力、应变）写入到plt格式的文件中

GLOBAL_variable;                                       %调用全局变量
fid_result=fopen('result.plt','w');
fprintf(fid_result,'TITLE="Static analysis of cantilever beam"\n');
fprintf(fid_result,'VARIABLES="x" "y" "z" "U1" "U2" "U3" "S11"  "S22" "S33" "S12" "S13" "S23""E11"  "E22" "E33" "E12" "E13" "E23"\n');
fprintf(fid_result,'ZONE T="flow-field", N= %8d,E=%8d,ET=BRICK, F=FEPOINT\n',nnode,nele);
for i=1:nnode
    fprintf(fid_result,'%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e\n',coordinate_value(i,1)+disp(3*i-2),coordinate_value(i,2)+disp(3*i-1),coordinate_value(i,3)+disp(3*i),disp(3*i-2),disp(3*i-1),disp(3*i),node_stress(1,i),node_stress(2,i),node_stress(3,i),node_stress(4,i),node_stress(5,i),node_stress(6,i),node_strain(1,i),node_strain(2,i),node_strain(3,i),node_strain(4,i),node_strain(5,i),node_strain(6,i));
end
for i=1:nele
    fprintf(fid_result,'%8d%8d%8d%8d%8d%8d%8d%8d\n',nodes(i,1),nodes(i,2),nodes(i,3),nodes(i,4),nodes(i,5),nodes(i,6),nodes(i,7),nodes(i,8));
end
end

