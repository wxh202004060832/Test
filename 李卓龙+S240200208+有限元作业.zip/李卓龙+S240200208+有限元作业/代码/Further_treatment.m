function [KK,FF] = Further_treatment( KK,FF,bcnodes,loadnodes,sdof ) 
% 本函数通过约束节点和加载节点来对系统的刚度矩阵和载荷矩阵进行处理

GLOBAL_variable;                           %调用全局变量


bcdof=[];                                  %通过约束节点来对系统刚度矩阵KK进行处理
T1=length(bcnodes);
for i=1:T1
        bcdof=[bcdof 3*bcnodes(i)-2 3*bcnodes(i)-1 3*bcnodes(i)];
end  
for i=1:3*T1
    c=bcdof(i);
    for j=1:sdof
        KK(c,j)=0;
    end
    KK(c,c)=1;
end


T2=length(loadnodes);                %通过加载节点来对系统的载荷矩阵FF进行处理
for i=1:T2
        Fy=3*loadnodes(i);
        FF(Fy)=100;                  %在节点的Y轴方向施加集中力

end
end
