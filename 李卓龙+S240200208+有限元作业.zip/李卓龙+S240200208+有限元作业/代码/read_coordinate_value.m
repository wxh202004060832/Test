function coordinate_value = read_coordinate_value
%  本函数用于从inp文件中读取节点的坐标信息
fidin=fopen('model.inp');
i=1;
 while 1
        tline = fgetl(fidin);                           
        if strncmpi(tline,'*Node',5)==1   
            while 1
                tline=fgetl(fidin);
                if strncmpi(tline,'*Element, type=C3D8R',20)==1
                    break
                end
                   coord{i}=tline;
                   i=i+1;
            end
        end
        if strncmpi(tline,'*END',4)==1
            break
        end
 end
coord=coord';
coordinate_value=cell2mat(coord);
coordinate_value=str2num(coordinate_value);
coordinate_value=coordinate_value(:,2:4);