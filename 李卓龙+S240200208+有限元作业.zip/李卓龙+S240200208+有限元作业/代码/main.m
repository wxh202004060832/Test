%本程序通过六面体单元来对悬臂梁进行静态分析
%悬臂梁有320个单元

clear all                                            % 清理工作空间
format short  
t=cputime;                                         % 记录程序开始时间

GLOBAL_variable;                                   %定义全局变量，便于子函数进行调用

coordinate_value=read_coordinate_value;            %读取节点坐标值
nodes=read_nodes;                                  %读取每个单元的节点编号
bcnodes=read_bcnodes;                              %读取被施加约束的节点信息
loadnodes=read_loadnodes;                          %读取被施加集中力的节点信息
                                                                                                          
 nele=size(nodes,1);                               %系统的单元总数         
 nnode=size(coordinate_value,1);                   %系统的节点总数     
 nnele=8;                                          %每个单元的节点数目                        
 ndof=3;                                           %每个节点的自由度    
 edof=24;                                          %单个单元的自由度
 sdof=nnode*ndof;                                  %系统的自由度                    
 point=[-0.7745966692 0 0.7745966692];                   %高斯积分点的坐标
 weight=[0.55555555556 0.888888888889 0.55555555556];    %高斯积分点权重
 
 FF=zeros(sdof,1);                                %定义系统载荷矩阵

 KK=zeros(sdof,sdof);		                      %定义系统刚度矩阵
   
 E=210000;                                                      %杨氏模量           
 poisson=0.3;                                                     %泊松比
 constitutive_matrix=material_constitutive_matrix(E,poisson);                %本构矩阵
 
 KK=k_Assembly(point,weight,coordinate_value,nodes,constitutive_matrix,KK); %获得系统整体刚度矩阵KK

[KK,FF] = Further_treatment( KK,FF,bcnodes,loadnodes);         %进一步处理KK和FF矩阵

displacement=KK\FF;                                            %计算节点位移                                             

transition=trans_matrix;                                           % 对应所用形函数、积分点，获取高斯积分点应力向节点差值矩阵

[ strain,stress ] = strain_stress( point,weight,transition,displacement,constitutive_matrix );   % 根据位移结果计算应力和应变

[ node_strain,node_stress ] = ave_strain_stress( strain,stress );   % 对节点应力、应变进行平均化处理

result_inp(displacement,node_strain,node_stress);                   % 将计算结果写出到plt文件

solve_time = cputime-t                                              %计算求解时间