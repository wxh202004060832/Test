function KK=k_Assembly(point,weight,coordinate_value,nodes,constitutive_matrix,KK)
%本函数用于获得系统的刚度矩阵KK
%通过高斯积分可得到单元刚度矩阵k，将k进行组装即可得到KK

GLOBAL_variable;                      %调用全局变量

for perel=1:nele       
                                                            % 单元刚度矩阵k；
    for i=1:nnele
        nd(i)=nodes(perel,i);                                 % 获取单元对应节点
        xcoordinate(i)=coordinate_value(nd(i),1);           % 获取节点x轴坐标值
        ycoordinate(i)=coordinate_value(nd(i),2);           % 获取节点y轴坐标值     
        zcoordinate(i)=coordinate_value(nd(i),3);           % 获取节点z轴坐标值     
    end

    k=sparse(edof,edof);  
    for intx=1:3
        u=point(intx);
        wtx=weight(intx);
        for inty=1:3
            v=point(inty);
            wty=weight(inty);
            for intz=1:3     % 高斯积分点循环，积分（循环累加）得单元刚度矩阵；
                w=point(intz);
                wtz=weight(intz);
                [B,jdet]=BandJ_matrix(xcoordinate,ycoordinate,zcoordinate,u,v,w);
                k=k+jdet*wtx*wty*wtz*transpose(B)*constitutive_matrix*B;
            end
        end
    end 
    
                                                        %组装单元刚度矩阵来得到系统刚度矩阵；
    for i=1:8;
        dof(3*i-2)=3*nd(i)-2;
        dof(3*i-1)=3*nd(i)-1;
        dof(3*i)=3*nd(i);
    end
    for i=1:edof
        ii=dof(i);
        for j=1:edof
            jj=dof(j);
            KK(ii,jj)=KK(ii,jj)+k(i,j);
        end
    end
end
end