function transition = trans_matrix
%本函数用于创建转换矩阵

GLOBAL_variable;

p=0;
for i=1:3
    s=point(i);
    for j=1:3
        n=point(j);
        for z=1:3
            t=point(z);
            N1=(1-s)*(1-n)*(1-t)/8;
            N2=(1+s)*(1-n)*(1-t)/8;
            N3=(1+s)*(1+n)*(1-t)/8;
            N4=(1-s)*(1+n)*(1-t)/8;
            N5=(1-s)*(1-n)*(1+t)/8;
            N6=(1+s)*(1-n)*(1+t)/8;
            N7=(1+s)*(1+n)*(1+t)/8;
            N8=(1-s)*(1+n)*(1+t)/8;
            p=p+1;
            transition(p,:)=[N1,N2,N3,N4,N5,N6,N7,N8]; 
        end
    end
end