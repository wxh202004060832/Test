clear
clc

E=2e11;%弹性模量，Pa
u=0.4;%泊松比
q=100;%均布载荷
t=0.2;%厚度
D=[E/(1-u^2),u*E/(1-u^2),0;u*E/(1-u^2),E/(1-u^2),0;0,0,E/(2*(1+u))];%应力应变矩阵
bt=(3+0.5407762)*10^11;%乘大数法的大数
l=6;%长度
h=1;%宽度
ele_size=[0.1,0.1];%单元的两个直角边尺寸
ele_H=l/ele_size(1);%水平单元数
ele_V=h/ele_size(2);%竖向单元数
ele_num=ele_H*ele_V*2;%单元数
node_num=(ele_H+1)*(ele_V+1);%节点数
DOF=2;%每个节点自由度
A=1/2*ele_size(1)*ele_size(2);%单元面积

%定义每个单元的节点号
num=0;
for i=1:ele_H
    for j=1:ele_V
        num=num+1;
        ele(num,1)=1+(j-1)+(i-1)*(ele_V+1);
        ele(num,2)=1+(j-1)+i*(ele_V+1);
        ele(num,3)=2+(j-1)+(i-1)*(ele_V+1);
        num=num+1;
        ele(num,1)=1+j+(i-1)*(ele_V+1);
        ele(num,2)=1+(j-1)+i*(ele_V+1);
        ele(num,3)=2+(j-1)+i*(ele_V+1);
    end
end

%定义节点坐标
num=0;
for i=1:ele_H+1
    for j=1:ele_V+1
        num=num+1;
        node(num,1)=(i-1)*ele_size(1);%x
        node(num,2)=(j-1)*ele_size(2);%y
    end
end

%每个单元自由度在整体矩阵中的索引位置
ele_DOF=zeros(ele_num,DOF*3);
for i=1:ele_num
    for j=1:length(ele(i,:))
        ele_DOF(i,1+2*(j-1):2+2*(j-1))=2*(ele(i,j)-1)+1:2*(ele(i,j)-1)+2;
    end
end

function ke=ele_stiff_matrix(ele,node,i,A,D,t)
      
      b1=node(ele(i,2),2)-node(ele(i,3),2);%b1=y1-y3
      b2=node(ele(i,3),2)-node(ele(i,1),2);
      b3=node(ele(i,1),2)-node(ele(i,2),2);
      c1=node(ele(i,3),1)-node(ele(i,2),1);%c1=x3-x2
      c2=node(ele(i,1),1)-node(ele(i,3),1);
      c3=node(ele(i,2),1)-node(ele(i,1),1);
      
      B(:,:,i)=1/(2*A)*[b1, 0 , b2, 0 , b3, 0 ;
                        0 , c1, 0 , c2, 0 , c3;
                        c1, b1, c2, b2, c3, b3];%单元B矩阵

      ke=B(:,:,i)'*D*B(:,:,i)*t*A;
end

KZ=zeros(node_num*2,node_num*2);
for i=1:ele_num
    ke=ele_stiff_matrix(ele,node,i,A,D,t);%单元刚度矩阵
    KZ(ele_DOF(i,:),ele_DOF(i,:)) = KZ(ele_DOF(i,:),ele_DOF(i,:))+ke;
end

%计算总节点载荷阵列
P=[];
P(2*(ele_V+1))=-1/2*q*t*ele_size(1);
for i=2:ele_H
    P(18+2*(ele_V+1)*(i-1))=-q*t*ele_size(1);
end
P(node_num*2)=-1/2*q*t*ele_size(1);
PZ=P';%总节点载荷阵列

%乘大数法施加约束条件，最左侧节点全部固定
cons_DOF=(1:(ele_V+1)*2);%约束自由度编号
Disp=zeros(length(cons_DOF),1);%位移为0
for i=1:length(cons_DOF)
    KZ(cons_DOF(i),cons_DOF(i))=bt*KZ(cons_DOF(i),cons_DOF(i));
    PZ(cons_DOF(i))=Disp(i)*KZ(cons_DOF(i),cons_DOF(i));
end

a=inv(KZ)*PZ;%结点位移列阵

% 初始化应变矩阵
eps = zeros(3, ele_num);

function [sgm, eps] = stress_calculate(ele, node, i, A, D, t, a)

    b1 = node(ele(i,2),2) - node(ele(i,3),2);
    b2 = node(ele(i,3),2) - node(ele(i,1),2);
    b3 = node(ele(i,1),2) - node(ele(i,2),2);
    c1 = -node(ele(i,2),1) + node(ele(i,3),1);
    c2 = -node(ele(i,3),1) + node(ele(i,1),1);
    c3 = -node(ele(i,1),1) + node(ele(i,2),1);
    
    B = 1/(2*A) * [b1, 0, b2, 0, b3, 0; 
                    0, c1, 0, c2, 0, c3; 
                    c1, b1, c2, b2, c3, b3];
    
    ae = [a(2*ele(i,1)-1); a(2*ele(i,1)); 
          a(2*ele(i,2)-1); a(2*ele(i,2)); 
          a(2*ele(i,3)-1); a(2*ele(i,3))];
    
    eps = B * ae; % 单元应变
    sgm = D * eps; % 单元应力
end

%计算每个单元的应力和应变
for i = 1:ele_num
    [sgm(:,i), eps(:,i)] = stress_calculate(ele, node, i, A, D, t, a); % 单元应力和应变
end

%重新排列位移矩阵
SF=1/10*1/max(abs(a));%位移放大系数
new_node=node+SF*reshape(a,2,length(a)/2)';%计算变形后的坐标

% 计算结果处理
figure
patch('Faces',ele,'Vertices',node,'FaceColor','none','EdgeColor','g')
hold on;
patch('Faces',ele,'Vertices',new_node,'FaceColor','none')
xlabel('x')
ylabel('y')
title('位移')
axis equal

figure
patch('Faces',ele,'Vertices',node,'FaceVertexCData',sgm(1,:)','FaceColor','flat')
axis equal
xlabel('x')
ylabel('y')
title('应力')
colorbar
colormap(jet)

figure
patch('Faces', ele, 'Vertices', node, 'FaceVertexCData', eps(1,:)','FaceColor', 'flat')
axis equal
xlabel('x')
ylabel('y')
title('应变 \epsilon')
colorbar
colormap(jet)