clc,clear,close all
addpath(genpath('E:\桌面代存\优化作业\优化大作业\code'));

% 载入企鹅数据集
[X,Y] = xlsread('penguins_size.csv',1,'A2:F343');
Characteristic = X([1:146,152:214,220:337],:);   % 数据的特征
Label = Y([1:146,152:214,220:337],:);            % 数据的类别

% 训练
% 多类SVM分类器
rng(1);
t = templateSVM('Standardize',true,'KernelFunction','gaussian');
SVMModel = fitcecoc(Characteristic,Label,'Learners',t,'FitPosterior',true,...
                    'ClassNames',{'Adelie','Chinstrap','Gentoo'},...
                    'Verbose',2);

% 交叉验证
CVSVMModel = crossval(SVMModel);
classLoss = kfoldLoss(CVSVMModel);
%显示损失量
disp(['Classification loss: ', num2str(classLoss)]);

%测试
% 新数据点
newData =X([147:151,215:219,338:341],:);
% 使用训练好的SVM模型进行预测
predictedLabels = predict(SVMModel, newData);
% 显示预测结果
disp('Predicted class labels for the new data points:');
for i = 1:length(predictedLabels)
      disp(['Data point ', num2str(i), ': ', char(predictedLabels{i})]);
end




